#include <string>
#include <iostream>

using namespace std;

class fecha {
    public:
        fecha (int _mes, int _dia, int _año)
        {
            mes = _mes;
            dia = _dia;
            año = _año;
        }

        void getfecha (int _mes, int _dia, int _año){
            mes = _mes;
            dia = _dia;
            año = _año;
        
        }

        void setmes (int _mes){
            mes = _mes;
        }

        void setdia (int _dia){
            dia = _dia;
        }
        void setaño (int _año){
            año = _año;
        }

        int getmes (){
            return mes;
        }

        int getdia () {
            return dia;
        }

        int getaño () {
            return año;
        }

        int mesV(int _mes){
            if (_mes >= 1 && _mes <= 12){
                mes = _mes;
            } else {mes = 1;}
        }

        int displayDates() {
            cout << "mes: " << mes << endl;
            cout << "dia: " << dia << endl;
            cout << "año: " << año << endl;
        }

    private:
        int mes;
        int dia;
        int año;
    
};