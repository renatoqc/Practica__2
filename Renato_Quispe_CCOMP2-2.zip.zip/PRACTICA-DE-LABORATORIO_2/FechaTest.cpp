#include <iostream>
#include "fecha.h"

using namespace std;

int main()
{
    

    int _mes, _dia, _año;

    cout << "Ingrese el mes: " << endl;
    cin >> _mes;
    cout << "Ingrese el dia: " << endl;
    cin >> _dia;
    cout << "Ingrese el año; " << endl;
    cin >> _año;


    
}